import json
import re

# 定义用于去除控制字符的正则表达式
control_chars = re.compile(r'[\x00-\x1F\x7F]')


# 定义函数用于清理控制字符
def remove_control_characters(s):
    return control_chars.sub('', s)


# 定义函数用于修复无效的转义字符
def fix_invalid_escapes(s):
    # 匹配无效的转义序列（反斜杠后面不是有效的转义字符）
    # 有效的转义字符: " \ / b f n r t u
    pattern = r'\\(?![\\"/bfnrt]|u[0-9a-fA-F]{4})'
    # 将无效的转义替换为双反斜杠（转义反斜杠本身）
    return re.sub(pattern, r'\\\\', s)


# 初始化空字符串存储清理后的内容
cleaned_content = ''

# 逐行读取并清理文件
with open('input.json', 'r', encoding='utf-8') as f:
    for line in f:
        # 先去除控制字符
        cleaned_line = remove_control_characters(line)
        # 再修复无效转义
        cleaned_line = fix_invalid_escapes(cleaned_line)
        cleaned_content += cleaned_line

# 打印部分内容进行调试
print(cleaned_content[1234170:1234200])  # 打印清理后的前1000个字符以检查是否有问题

# 解析为 JSON 对象
try:
    data = json.loads(cleaned_content)
    print("JSON 文件成功解析")
except json.JSONDecodeError as e:
    print(f"解析 JSON 时出错: {e}")

    # 如果仍然出错，尝试更宽松的解析方式
    try:
        # 使用更宽松的解析器，忽略更多错误
        import ijson
        from ijson.compat import BytesIO

        print("尝试使用宽松模式解析...")
        # 重新读取文件并使用 ijson 解析
        with open('input.json', 'r', encoding='utf-8') as f:
            content = f.read()
            # 应用更严格的清理
            content = remove_control_characters(content)
            content = fix_invalid_escapes(content)
            # 尝试再次解析
            data = json.loads(content)
            print("JSON 文件成功解析（第二次尝试）")
    except Exception as e2:
        print(f"第二次解析也失败: {e2}")

        # 最后尝试：手动定位并修复错误
        try:
            print("尝试手动修复错误...")
            # 查找错误位置附近的上下文
            error_pos = e.pos if hasattr(e, 'pos') else 739646
            start = max(0, error_pos - 50)
            end = min(len(cleaned_content), error_pos + 50)
            error_context = cleaned_content[start:end]
            print(f"错误位置附近的上下文: {error_context}")

            # 尝试删除错误位置的字符
            if error_pos < len(cleaned_content):
                cleaned_content = cleaned_content[:error_pos] + cleaned_content[error_pos + 1:]
                data = json.loads(cleaned_content)
                print("JSON 文件成功解析（手动修复后）")
            else:
                exit(1)
        except Exception as e3:
            print(f"所有解析尝试都失败: {e3}")
            exit(1)


# 定义递归函数清理数据中的控制字符
def clean_data(obj):
    if isinstance(obj, str):
        return remove_control_characters(obj)
    elif isinstance(obj, list):
        return [clean_data(item) for item in obj]
    elif isinstance(obj, dict):
        return {key: clean_data(value) for key, value in obj.items()}
    else:
        return obj


# 清理 JSON 数据中的控制字符
cleaned_data = clean_data(data)

# 保存清理后的 JSON 文件
with open('train.json', 'w', encoding='utf-8') as f:
    json.dump(cleaned_data, f, ensure_ascii=False, indent=4)

print("清理后的 JSON 文件已保存为 train.json")


